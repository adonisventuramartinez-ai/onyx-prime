"use client";

export const dynamic = "force-dynamic";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { ArrowLeft, Search, Sparkles, Loader2, ExternalLink, CheckCircle, AlertCircle } from "lucide-react";

interface PeliculaEncontrada {
  tmdb_id: number; // 👈 Agregado
  titulo: string;
  anio: string;
  genero: string;
  sinopsis: string;
  caratula: string;
  link_directo: string;
  fuente: string;
}

export default function AgregarAutoPage() {
  const router = useRouter();
  const [nombre, setNombre] = useState("");
  const [cargando, setCargando] = useState(false);
  const [resultado, setResultado] = useState<PeliculaEncontrada | null>(null);
  const [error, setError] = useState("");
  const [guardando, setGuardando] = useState(false);
  const [guardado, setGuardado] = useState(false);

  const buscarPelicula = async () => {
    if (!nombre.trim()) {
      setError("Escribe el nombre de la película");
      return;
    }

    setCargando(true);
    setError("");
    setResultado(null);
    setGuardado(false);

    try {
      const res = await fetch(`/api/buscar-pelicula?nombre=${encodeURIComponent(nombre)}`);
      const data = await res.json();

      if (!res.ok) {
        setError(data.error || "No se encontró la película");
        return;
      }

      setResultado(data.pelicula);
    } catch (err) {
      setError("Error al buscar la película");
    } finally {
      setCargando(false);
    }
  };

  const guardarPelicula = async () => {
    if (!resultado) return;

    setGuardando(true);
    try {
      const res = await fetch("/api/peliculas", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          tmdb_id: resultado.tmdb_id, // 👈 Se envía el tmdb_id
          titulo: resultado.titulo,
          anio: resultado.anio,
          genero: resultado.genero,
          sinopsis: resultado.sinopsis,
          caratula: resultado.caratula,
          link_directo: resultado.link_directo || "",
          fuente: "auto",
        }),
      });

      if (res.ok) {
        setGuardado(true);
        setTimeout(() => router.push("/admin"), 1500);
      } else {
        const data = await res.json();
        setError(data.error || "Error al guardar");
      }
    } catch (err) {
      setError("Error al guardar");
    } finally {
      setGuardando(false);
    }
  };

  return (
    <main className="min-h-screen bg-[#141414] text-white p-4">
      <div className="max-w-3xl mx-auto">
        <Link
          href="/admin"
          className="inline-flex items-center gap-2 text-gray-400 hover:text-white mb-6 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" /> Volver al panel
        </Link>

        <h1 className="text-2xl font-bold mb-2">
          Buscar <span className="text-purple-400">Automático</span>
        </h1>
        <p className="text-gray-400 text-sm mb-6">
          Escribe el nombre de la película. El sistema buscará en TMDB y guardará el ID automáticamente.
        </p>

        <div className="flex gap-3 mb-6">
          <input
            type="text"
            placeholder="Ej: Inception, El Padrino, La Odisea..."
            value={nombre}
            onChange={(e) => setNombre(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && buscarPelicula()}
            className="flex-1 bg-white/5 border border-white/15 rounded-lg px-4 py-3 focus:border-purple-500 focus:outline-none text-white placeholder-gray-500"
          />
          <button
            onClick={buscarPelicula}
            disabled={cargando}
            className="bg-purple-600 hover:bg-purple-700 text-white px-6 py-3 rounded-lg font-semibold flex items-center gap-2 transition-colors disabled:opacity-50"
          >
            {cargando ? <Loader2 className="w-5 h-5 animate-spin" /> : <Search className="w-5 h-5" />}
            Buscar
          </button>
        </div>

        {error && (
          <div className="rounded-xl p-4 mb-6 flex items-start gap-3 bg-red-500/10 border border-red-500/30 text-red-400">
            <AlertCircle className="w-5 h-5 flex-shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        {cargando && (
          <div className="text-center py-12">
            <Loader2 className="w-12 h-12 animate-spin text-purple-400 mx-auto mb-4" />
            <p className="text-gray-400">Buscando en TMDB...</p>
          </div>
        )}

        {resultado && !cargando && (
          <div className={`bg-white/5 border rounded-2xl p-6 ${guardado ? 'border-green-500/50' : 'border-white/10'}`}>
            <div className="flex flex-col sm:flex-row items-start gap-6">
              <div className="w-32 flex-shrink-0 mx-auto sm:mx-0">
                {resultado.caratula ? (
                  <img
                    src={resultado.caratula}
                    alt={resultado.titulo}
                    className="w-full rounded-lg shadow-lg"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = '';
                    }}
                  />
                ) : (
                  <div className="w-full aspect-[2/3] bg-gray-800 rounded-lg flex items-center justify-center text-gray-500 text-sm">
                    Sin imagen
                  </div>
                )}
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between">
                  <div>
                    <h2 className="text-2xl font-bold">{resultado.titulo}</h2>
                    <div className="flex flex-wrap gap-3 mt-1">
                      <span className="text-sm text-gray-400">{resultado.anio}</span>
                      <span className="text-sm text-gray-400">{resultado.genero}</span>
                      <span className="text-xs bg-purple-500/20 text-purple-400 px-2 py-0.5 rounded-full">
                        🎬 TMDB ID: {resultado.tmdb_id}
                      </span>
                    </div>
                  </div>
                  {guardado && (
                    <span className="flex items-center gap-1 text-green-400 text-sm bg-green-500/20 px-3 py-1 rounded-full">
                      <CheckCircle className="w-4 h-4" /> Guardado
                    </span>
                  )}
                </div>

                <p className="text-gray-300 text-sm mt-3 line-clamp-3">{resultado.sinopsis}</p>

                {!guardado && (
                  <button
                    onClick={guardarPelicula}
                    disabled={guardando}
                    className="mt-4 bg-purple-600 hover:bg-purple-700 text-white px-6 py-2 rounded-xl font-semibold flex items-center gap-2 transition-colors disabled:opacity-50"
                  >
                    {guardando ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                    {guardando ? "Guardando..." : "Guardar en catálogo"}
                  </button>
                )}

                <p className="text-xs text-gray-500 mt-3">
                  ✅ El ID de TMDB ({resultado.tmdb_id}) se guardará automáticamente para poder reproducir la película.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </main>
  );
}
